import React from 'react'

function JobSeekerDashboard() {
  return (
    <div>JobSeekerDashboard</div>
  )
}

export default JobSeekerDashboard